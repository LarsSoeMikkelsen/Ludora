/*
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: MIT
 */

#ifndef VN_PROTOCOL_DRIVER_CS_H
#define VN_PROTOCOL_DRIVER_CS_H

#include <assert.h>

/*
 * These types/functions are expected
 *
 *   struct vn_cs_encoder
 *   vn_cs_encoder_get_len
 *   vn_cs_encoder_reserve
 *   vn_cs_encoder_write
 *
 *   struct vn_cs_decoder
 *   vn_cs_decoder_set_fatal
 *   vn_cs_decoder_read
 *   vn_cs_decoder_peek
 *
 *   vn_cs_handle_load_id
 *   vn_cs_handle_store_id
 */
#include "vn_cs.h"

static inline void
vn_encode(struct vn_cs_encoder *enc, size_t size, const void *data, size_t data_size)
{
   assert(size % 4 == 0);
   /* TODO check if the generated code is optimal */
   vn_cs_encoder_write(enc, size, data, data_size);
}

static inline void
vn_decode(struct vn_cs_decoder *dec, size_t size, void *data, size_t data_size)
{
   assert(size % 4 == 0);
   vn_cs_decoder_read(dec, size, data, data_size);
}

#endif /* VN_PROTOCOL_DRIVER_CS_H */
